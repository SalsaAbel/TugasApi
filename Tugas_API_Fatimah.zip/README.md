# Tugas API Fatimah

## Fitur
- Read all data (GET) untuk tabel `genre` dan `author`
- Create data (POST) untuk tabel `genre` dan `author`
- Diuji menggunakan Postman

## Endpoint
| Resource | Method | URL | Keterangan |
|-----------|---------|-----|-------------|
| Author | GET | /api/authors | Menampilkan semua author |
| Author | POST | /api/authors | Menambahkan author baru |
| Genre | GET | /api/genres | Menampilkan semua genre |
| Genre | POST | /api/genres | Menambahkan genre baru |

## Langkah Testing
1. Jalankan `php artisan migrate`
2. Gunakan Postman untuk uji endpoint
3. Format data JSON:
   ```json
   {
     "name": "Nama Genre",
     "description": "Deskripsi Genre"
   }
   ```
   atau
   ```json
   {
     "name": "Nama Author",
     "email": "email@example.com",
     "bio": "Bio singkat"
   }
   ```
